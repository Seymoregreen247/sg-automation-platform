const SPREADSHEET_ID = "1RhkWOGU1wbrSHd4c3VYilUbpY4-bfm7jCJRzwlrWIbI";
const SHEET_NAME = "Sheet1";
const TIME_ZONE = "America/New_York";
const HEADERS = [
  "Timestamp",
  "Campaign ID",
  "Client Name",
  "Campaign Name",
  "QR Slug",
  "Destination URL",
  "Tracking Link",
  "Scan Count",
  "Last Scan",
  "City",
  "Device Type",
  "Notes",
  "Campaign Type",
  "Static / Dynamic",
  "Customer Email",
  "Customer Phone"
];

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  try {
    const data = parseRequest_(e);
    const sheet = getSheet_();
    ensureHeaders_(sheet);

    const campaignId = data.campaignId || createCampaignId_();
    const slug = data.slug || "";
    const row = [
      new Date(),
      campaignId,
      data.clientName || "",
      data.campaignName || "",
      slug,
      data.destination || "",
      data.trackingLink || "",
      Number(data.scanCount || 0),
      "",
      data.city || "",
      data.device || "",
      data.notes || "",
      data.campaignType || "",
      data.staticOrDynamic || "Static",
      data.customerEmail || "",
      data.customerPhone || ""
    ];

    const existingRow = findCampaignRow_(sheet, campaignId, slug);
    if (existingRow > 1) {
      sheet.getRange(existingRow, 1, 1, HEADERS.length).setValues([row]);
    } else {
      sheet.appendRow(row);
    }

    sheet.getRange(2, 1, Math.max(sheet.getLastRow() - 1, 1), 1).setNumberFormat("m/d/yyyy h:mm:ss");
    return json_({ result: "success", campaignId: campaignId });
  } catch (error) {
    return json_({ result: "error", message: error.message });
  } finally {
    lock.releaseLock();
  }
}

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || "status";
  if (action === "track") {
    return trackAndRedirect_((e.parameter.slug || "").trim());
  }
  return ContentService
    .createTextOutput("SG Automation Platform Script is live.")
    .setMimeType(ContentService.MimeType.TEXT);
}

function trackAndRedirect_(slug) {
  if (!slug) return HtmlService.createHtmlOutput("Missing campaign slug.");

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  let destination = "https://seymoregreen.com";

  try {
    const sheet = getSheet_();
    ensureHeaders_(sheet);
    const lastRow = sheet.getLastRow();
    if (lastRow > 1) {
      const rows = sheet.getRange(2, 1, lastRow - 1, HEADERS.length).getValues();
      const index = rows.findIndex(row => String(row[4]).trim() === slug);
      if (index >= 0) {
        const rowNumber = index + 2;
        destination = rows[index][5] || destination;
        const scans = Number(rows[index][7] || 0) + 1;
        sheet.getRange(rowNumber, 8).setValue(scans);
        sheet.getRange(rowNumber, 9).setValue(new Date()).setNumberFormat("m/d/yyyy h:mm:ss");
      }
    }
  } finally {
    lock.releaseLock();
  }

  const safeUrl = String(destination).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const jsUrl = JSON.stringify(String(destination));
  return HtmlService.createHtmlOutput(
    '<!doctype html><html><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<meta http-equiv="refresh" content="0;url=' + safeUrl + '">' +
    '<title>Opening campaign…</title></head><body style="font-family:Arial;padding:32px">' +
    '<p>Opening campaign…</p><p><a href="' + safeUrl + '">Continue</a></p>' +
    '<script>window.location.replace(' + jsUrl + ');<\/script></body></html>'
  );
}

function getSheet_() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  ss.setSpreadsheetTimeZone(TIME_ZONE);
  return ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
}

function ensureHeaders_(sheet) {
  sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
  sheet.setFrozenRows(1);
  sheet.getRange(1, 1, 1, HEADERS.length)
    .setFontWeight("bold")
    .setBackground("#173C0B")
    .setFontColor("#FFFFFF");
}

function findCampaignRow_(sheet, campaignId, slug) {
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return 0;
  const values = sheet.getRange(2, 2, lastRow - 1, 4).getDisplayValues();
  const match = values.findIndex(row =>
    (campaignId && row[0] === campaignId) || (slug && row[3] === slug)
  );
  return match >= 0 ? match + 2 : 0;
}

function parseRequest_(e) {
  if (e && e.postData && e.postData.contents) {
    try {
      return JSON.parse(e.postData.contents);
    } catch (error) {
      // Form-encoded requests are handled below.
    }
  }
  return (e && e.parameter) || {};
}

function createCampaignId_() {
  return "SGQR-" + Utilities.formatDate(new Date(), TIME_ZONE, "yyMMdd-HHmmss");
}

function json_(value) {
  return ContentService
    .createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}
